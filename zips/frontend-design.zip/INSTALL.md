# Installing Frontend Design

## 1. Create the folder

    mkdir -p ~/.claude/skills/frontend-design

On Windows use %USERPROFILE%\.claude\skills\frontend-design instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    frontend-design/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Frontend Design by name.

---

## Where this came from

- Skill: Frontend Design
- Author / repository: anthropics/skills
- Licence: NONE DECLARED
- Upstream: https://github.com/anthropics/skills
- Recorded: 923,000 installs, rank 7 all time

We did not write Frontend Design. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
