# Installing Superpowers

## 1. Create the folder

    mkdir -p ~/.claude/skills/superpowers

On Windows use %USERPROFILE%\.claude\skills\superpowers instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    superpowers/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Superpowers by name.

---

## Where this came from

- Skill: Superpowers
- Author / repository: obra/superpowers
- Licence: MIT
- Upstream: https://github.com/obra/superpowers
- Recorded: 291,648 stars

We did not write Superpowers. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
