# Installing I Have ADHD

## 1. Create the folder

    mkdir -p ~/.claude/skills/i-have-adhd

On Windows use %USERPROFILE%\.claude\skills\i-have-adhd instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    i-have-adhd/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
I Have ADHD by name.

---

## Where this came from

- Skill: I Have ADHD
- Author / repository: ayghri/i-have-adhd
- Licence: MIT
- Upstream: https://github.com/ayghri/i-have-adhd
- Recorded: 51,205 stars, previously miscounted as 6,200

We did not write I Have ADHD. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
