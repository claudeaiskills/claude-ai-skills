# Installing Security Audit Skill

## 1. Create the folder

    mkdir -p ~/.claude/skills/security-audit

On Windows use %USERPROFILE%\.claude\skills\security-audit instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    security-audit/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Security Audit Skill by name.

---

## Where this came from

- Skill: Security Audit Skill
- Author / repository: cloudflare/security-audit-skill
- Licence: MIT
- Upstream: https://github.com/cloudflare/security-audit-skill
- Recorded: 21,642 stars, trending Sep 2026

We did not write Security Audit Skill. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
