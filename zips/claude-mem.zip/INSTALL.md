# Installing Claude Mem

## 1. Create the folder

    mkdir -p ~/.claude/skills/claude-mem

On Windows use %USERPROFILE%\.claude\skills\claude-mem instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    claude-mem/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Claude Mem by name.

---

## Where this came from

- Skill: Claude Mem
- Author / repository: thedotmack/claude-mem
- Licence: Apache-2.0
- Upstream: https://github.com/thedotmack/claude-mem
- Recorded: 94,700 stars

We did not write Claude Mem. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
