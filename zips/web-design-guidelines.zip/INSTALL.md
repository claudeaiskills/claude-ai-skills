# Installing Web Design Guidelines

## 1. Create the folder

    mkdir -p ~/.claude/skills/web-design-guidelines

On Windows use %USERPROFILE%\.claude\skills\web-design-guidelines instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    web-design-guidelines/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Web Design Guidelines by name.

---

## Where this came from

- Skill: Web Design Guidelines
- Author / repository: vercel-labs/agent-skills
- Licence: NONE DECLARED
- Upstream: https://github.com/vercel-labs/agent-skills
- Recorded: 133,000 weekly installs

We did not write Web Design Guidelines. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
