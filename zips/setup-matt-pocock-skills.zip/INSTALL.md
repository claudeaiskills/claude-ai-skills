# Installing Setup Matt Pocock Skills

## 1. Create the folder

    mkdir -p ~/.claude/skills/setup-matt-pocock-skills

On Windows use %USERPROFILE%\.claude\skills\setup-matt-pocock-skills instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    setup-matt-pocock-skills/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Setup Matt Pocock Skills by name.

---

## Where this came from

- Skill: Setup Matt Pocock Skills
- Author / repository: mattpocock/skills
- Licence: MIT
- Upstream: https://github.com/mattpocock/skills
- Recorded: 892,000 installs

We did not write Setup Matt Pocock Skills. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
