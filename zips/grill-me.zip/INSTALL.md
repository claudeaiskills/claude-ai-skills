# Installing Grill Me

## 1. Create the folder

    mkdir -p ~/.claude/skills/grill-me

On Windows use %USERPROFILE%\.claude\skills\grill-me instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    grill-me/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Grill Me by name.

---

## Where this came from

- Skill: Grill Me
- Author / repository: mattpocock/skills
- Licence: MIT
- Upstream: https://github.com/mattpocock/skills
- Recorded: 1,200,000 installs as grill-me, plus 1,000,000 as grill-with-docs and 776,000 as grilling

We did not write Grill Me. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
