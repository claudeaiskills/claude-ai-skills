# The Top 20 Judgement Audit

Every top install is a judgement skill. Not one sends an invoice.

## The finding

- 20 most installed skills checked one by one.
- 0 of them send an invoice.
- 0 of them fill a CRM.
- 0 of them answer support tickets.
- 0 of them book an appointment.
- Every single one is a judgement skill: pick the right tool, argue back, read the room, check the sources before designing.
- The interesting read is not that automation is missing. It is that judgement is what people actually pay to borrow.

## Where to actually get it

- Upstream: https://claudeaiskills.github.io/claude-ai-skills/credits.html
- Licence: our own work

We are not shipping the code for this one. It is our own written analysis, so it is a document rather than third party code.

The link above is the authoritative source. If you want the workflow itself,
follow the upstream instructions.
