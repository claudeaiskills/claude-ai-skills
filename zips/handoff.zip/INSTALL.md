# Installing Handoff

## 1. Create the folder

    mkdir -p ~/.claude/skills/handoff

On Windows use %USERPROFILE%\.claude\skills\handoff instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    handoff/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Handoff by name.

---

## Where this came from

- Skill: Handoff
- Author / repository: mattpocock/skills
- Licence: MIT
- Upstream: https://github.com/mattpocock/skills
- Recorded: 869,000 installs, rank 9 all time

We did not write Handoff. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
