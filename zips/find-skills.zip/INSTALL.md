# Installing Find Skills

## 1. Create the folder

    mkdir -p ~/.claude/skills/find-skills

On Windows use %USERPROFILE%\.claude\skills\find-skills instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    find-skills/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Find Skills by name.

---

## Where this came from

- Skill: Find Skills
- Author / repository: vercel-labs/skills
- Licence: MIT
- Upstream: https://github.com/vercel-labs/skills
- Recorded: 3,600,000 installs, rank 1 all time

We did not write Find Skills. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
