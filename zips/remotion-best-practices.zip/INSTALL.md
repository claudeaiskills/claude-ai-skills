# Installing Remotion Best Practices

## 1. Create the folder

    mkdir -p ~/.claude/skills/remotion-best-practices

On Windows use %USERPROFILE%\.claude\skills\remotion-best-practices instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    remotion-best-practices/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Remotion Best Practices by name.

---

## Where this came from

- Skill: Remotion Best Practices
- Author / repository: remotion-dev/skills
- Licence: NONE DECLARED
- Upstream: https://github.com/remotion-dev/skills
- Recorded: 117,000 weekly installs

We did not write Remotion Best Practices. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
