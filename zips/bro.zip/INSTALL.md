# Installing bro

## 1. Create the folder

    mkdir -p ~/.claude/skills/bro

On Windows use %USERPROFILE%\.claude\skills\bro instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    bro/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
bro by name.

---

## Where this came from

- Skill: bro
- Author / repository: dmmulroy/.dotfiles
- Licence: NONE DECLARED
- Upstream: https://github.com/dmmulroy/.dotfiles
- Recorded: 962 stars, viral 4 Aug 2026

We did not write bro. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
