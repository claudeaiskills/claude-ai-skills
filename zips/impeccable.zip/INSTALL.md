# Installing Impeccable

## 1. Create the folder

    mkdir -p ~/.claude/skills/impeccable

On Windows use %USERPROFILE%\.claude\skills\impeccable instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    impeccable/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Impeccable by name.

---

## Where this came from

- Skill: Impeccable
- Author / repository: pbakaus/impeccable
- Licence: Apache-2.0
- Upstream: https://github.com/pbakaus/impeccable
- Recorded: 71,177 stars, 17 commands

We did not write Impeccable. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
