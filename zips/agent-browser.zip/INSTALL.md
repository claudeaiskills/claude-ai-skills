# Installing Agent Browser

## 1. Create the folder

    mkdir -p ~/.claude/skills/agent-browser

On Windows use %USERPROFILE%\.claude\skills\agent-browser instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    agent-browser/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Agent Browser by name.

---

## Where this came from

- Skill: Agent Browser
- Author / repository: vercel-labs/agent-browser
- Licence: Apache-2.0
- Upstream: https://github.com/vercel-labs/agent-browser
- Recorded: 943,000 installs, rank 6 all time

We did not write Agent Browser. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
