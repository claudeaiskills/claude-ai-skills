# Installing Anti Slop: Ponytail and Taste

## 1. Create the folder

    mkdir -p ~/.claude/skills/anti-slop

On Windows use %USERPROFILE%\.claude\skills\anti-slop instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    anti-slop/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Anti Slop: Ponytail and Taste by name.

---

## Where this came from

- Skill: Anti Slop: Ponytail and Taste
- Author / repository: DietrichGebert/ponytail and Leonxlnx/taste-skill
- Licence: MIT (both)
- Upstream: https://github.com/DietrichGebert/ponytail
- Recorded: ponytail 145,985 stars, taste-skill 90,135 stars

We did not write Anti Slop: Ponytail and Taste. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
