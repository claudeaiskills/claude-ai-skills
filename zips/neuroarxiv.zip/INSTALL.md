# Installing Neuroarxiv

## 1. Create the folder

    mkdir -p ~/.claude/skills/neuroarxiv

On Windows use %USERPROFILE%\.claude\skills\neuroarxiv instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    neuroarxiv/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Neuroarxiv by name.

---

## Where this came from

- Skill: Neuroarxiv
- Author / repository: UditAkhourii/neuroarxiv
- Licence: MIT
- Upstream: https://github.com/UditAkhourii/neuroarxiv
- Recorded: 431 stars

We did not write Neuroarxiv. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
