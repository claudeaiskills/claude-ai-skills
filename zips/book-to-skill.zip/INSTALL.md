# Installing Book To Skill

## 1. Create the folder

    mkdir -p ~/.claude/skills/book-to-skill

On Windows use %USERPROFILE%\.claude\skills\book-to-skill instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    book-to-skill/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Book To Skill by name.

---

## Where this came from

- Skill: Book To Skill
- Author / repository: virgiliojr94/book-to-skill
- Licence: MIT
- Upstream: https://github.com/virgiliojr94/book-to-skill
- Recorded: 32,412 stars

We did not write Book To Skill. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
