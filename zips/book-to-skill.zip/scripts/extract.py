#!/usr/bin/env python3
"""
Extract text from a document file for book-to-skill processing.
Backward-compatible entrypoint wrapper.
"""

import os
import sys

# Keep a deployed skill directory clean: importing the package below would
# otherwise write __pycache__/*.pyc beside the sources, leaving build artifacts
# inside the skill. `__name__` is bound before the module body runs, so this
# holds for a direct invocation and never mutates an embedding process that
# merely imports this module. Must be set BEFORE `book_to_skill` is imported.
if __name__ == "__main__":
    sys.dont_write_bytecode = True

# Force UTF-8 stdout/stderr so extracted text, the attribution line's separators
# and the dependency-check glyphs (✓ / ✗) don't raise UnicodeEncodeError on Windows
# consoles that default to a legacy code page (e.g. GBK / cp936).
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):
        pass

# Ensure the project root directory (where the 'book_to_skill' package lives) is in sys.path
# so the modular package can be imported reliably regardless of the working directory.
sys.path.insert(0, str(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from book_to_skill.cli import main

if __name__ == "__main__":
    main()
