# The Skills Directory Audit

191,034 files, 19,200 authors, and nobody pays for placement.

## Why the no-paid-placement sentence matters

- 191,034 skill files across 1,500 repositories.
- 19,200 credited authors.
- Refreshed twice a day.
- And the line that makes the rest of it usable: nobody pays for placement or ranking.
- Most directories sell rank. Rank you can buy is not a measurement.
- This one has no revenue motive to promote anything, which is why the install counts in this whole series are worth arguing about.
- Every number in these 25 posts comes from that index, checked against GitHub directly where the claim mattered.

## Where to actually get it

- Upstream: https://claudeaiskills.github.io/claude-ai-skills/credits.html
- Licence: our own work

We are not shipping the code for this one. It is our own written analysis, so it is a document rather than third party code.

The link above is the authoritative source. If you want the workflow itself,
follow the upstream instructions.
