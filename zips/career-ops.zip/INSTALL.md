# Installing Career Ops

## 1. Create the folder

    mkdir -p ~/.claude/skills/career-ops

On Windows use %USERPROFILE%\.claude\skills\career-ops instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    career-ops/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Career Ops by name.

---

## Where this came from

- Skill: Career Ops
- Author / repository: santifer/career-ops
- Licence: MIT
- Upstream: https://github.com/santifer/career-ops
- Recorded: 72,799 stars

We did not write Career Ops. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
