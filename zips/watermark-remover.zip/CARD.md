# Claude Watermark Remover

Rank 14 on installs, and it exists to hide that Claude wrote it.

## Why this is a card and not a download

- The repository is real and reachable, and it carries a custom MarkClean licence, not an open source licence.
- We do not redistribute proprietary code, so the zip is not here.
- The upstream link is in this card. Go get it there.
- What is worth noticing: the skill does not make output better. It makes output undetectable.
- That is a choice about disclosure, and you should make it on purpose rather than by accident.

## Where to actually get it

- Upstream: https://github.com/Rjgyana/MarkClean-ClaudeWatermarkRemover
- Licence: PROPRIETARY, not redistributed

We are not shipping the code for this one. It is a proprietary application under a custom MarkClean licence.

The link above is the authoritative source. If you want the workflow itself,
follow the upstream instructions.
