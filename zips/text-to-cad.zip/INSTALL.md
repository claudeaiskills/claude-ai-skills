# Installing Text To CAD

## 1. Create the folder

    mkdir -p ~/.claude/skills/text-to-cad

On Windows use %USERPROFILE%\.claude\skills\text-to-cad instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    text-to-cad/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Text To CAD by name.

---

## Where this came from

- Skill: Text To CAD
- Author / repository: earthtojake/text-to-cad
- Licence: MIT
- Upstream: https://github.com/earthtojake/text-to-cad
- Recorded: 16,370 stars

We did not write Text To CAD. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
