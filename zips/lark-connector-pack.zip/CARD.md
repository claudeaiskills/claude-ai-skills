# Lark Connector Pack

Fourteen skills, fourteen identical install counts. That is the tell.

## How to read identical numbers

- Ranks 14 to 27 are all Lark connectors.
- lark-doc, lark-base, lark-drive, lark-shared, lark-im, lark-approval, lark-calendar, lark-sheets, lark-wiki, lark-contact, lark-slides.
- Every single one reports 727,000 installs.
- Fourteen products, fourteen identical numbers, zero variance.
- Real organic adoption does not do that. This is one platform shipping fourteen adapters and the leaderboard scoring each as a separate win.
- The sponsored slots are supposed to be the thing you skip past. Sometimes the shape of the data is the tell instead.

## Where to actually get it

- Upstream: https://claudeaiskills.github.io/claude-ai-skills/credits.html
- Licence: n/a, no public single repository

We are not shipping the code for this one. There is no single public repository for the connector set.

The link above is the authoritative source. If you want the workflow itself,
follow the upstream instructions.
