# Agentjacking Defence Checklist

A researcher got 85 percent field exploitation. This is the list of what must be true.

## The attack arrives as a build error

- Disclosed 14 June 2026. Reported 85 percent exploitation in field tests.
- Five of six real setups were compromised. This was not a lab model.
- The payload presents as an ordinary build or compile failure, so it reads as routine noise.
- Defence is a checklist, and the checklist is short. These must all be true:
- 1. An agent cannot install dependencies from an untrusted registry without a human approving it.
- 2. An agent cannot read a task description that came from a fetched web page and treat it as an instruction.
- 3. Build output and error text are treated as untrusted data, never as commands.
- 4. Every tool call is logged somewhere a human reads.
- 5. Secrets are scoped per tool, not ambient to the whole session.
- 6. There is a kill switch that does not require the agent's cooperation to use.

## Where to actually get it

- Upstream: https://claudeaiskills.github.io/claude-ai-skills/credits.html
- Licence: n/a, advisory writeup

We are not shipping the code for this one. It is a security advisory, not a released skill, so there is no code to ship.

The link above is the authoritative source. If you want the workflow itself,
follow the upstream instructions.
