# Message structures - reference

Contents: why openers die, the working copy pattern, tone rules, message
length limits, safety lines.

## Why most openers die

People ignore messages that look like templates. The instant a reader can
tell the same text went to 50 people, it is dead. Two things kill an
opener: pitching too early, and a hook that is not specific to them.

The purpose of the connection request is ONLY to be accepted and replied
to. The pitch comes later, after rapport. Do not combine both in one
message - combined messages convert worse and get reported as spam.

## The working copy pattern

Every message follows: name + specific hook first sentence, no pitch,
single soft ask, under the length limit.

Connection request skeleton:
```
Hi [name], [specific thing about them or their business].
[One line connecting that to what you do, framed as relevant to THEM].
Open to [one specific low-effort ask]?
```

Thanks note skeleton:
```
Thanks for connecting, [name].
[One line returning to the hook.] [One open question about their current priority.]
[Optional: one concrete observation, only if genuinely useful.]
```

Silent follow-up skeleton:
```
[name], [one new angle or micro-result, different from the request].
[One line connecting to their situation.] [Yes/no low-effort question.]
```

## Tone rules

- Write like a colleague who happens to sell something, never like a script
- Short sentences. Speakable. If it does not sound right read aloud, rewrite it
- Contractions welcome. "I'm" not "I am", "you're" not "you are"
- No "I hope this finds you well", "I trust this message reaches you",
  "circling back", "touching base", "just following up on my last"
- No emoji icons. No all-caps. No "!!!" or "???"
- No em dashes anywhere - use normal hyphens
- No invented stats, results, or mutual contacts

## Length limits (LinkedIn)

- Connection request: max 300 characters (visible area before "See more")
- First message after accept: ideally under 120 words
- Follow-up: under 80 words
- Comments: 10-20 words

## Safety lines

- Never fabricate a shared connection, a congratulations, or a post you did not see
- Do not send links until the prospect asks or shows interest
- One follow-up after silence, then stop. No nagging, no guilt-tripping
- Do not enable or suggest automation, scraping, or bulk messaging tools -
  LinkedIn detects and restricts them, and it gets real accounts flagged