# LinkedIn Outbound Sales - Install Guide

Install time: about 2 minutes.

## What you get

- `SKILL.md` - the workflow: connection request, thanks note, follow-up, comments
- `references/message-structures.md` - the tone rules and length limits

## How to install

### Claude (Desktop app / web with Projects, or Codex CLI)

1. Find your skills folder:
   - Claude Desktop: `~/.claude/skills/`
   - Codex CLI: `~/.codex/skills/`
2. Copy the whole `linkedin-outbound-sales` folder into it.
3. Restart the app.
4. Per-project: copy the folder into the project's `.claude/skills/` folder
   and it works for that project only.

### Any other AI tool

1. Keep the folder anywhere in the project.
2. In each session, paste this pointer:

   "Read `skills/linkedin-outbound-sales/SKILL.md` and its references folder,
   then follow the workflow."

## First run check

After installing, type something like:

"Write outreach for a SaaS founder selling to HR teams; prospect is an HR
director at a 200-person logistics company."

You should get: BRIEF, CONNECTION REQUEST, THANKS NOTE, FOLLOW-UP, COMMENTS -
in that order. If the connection request is over 300 characters or includes
a pitch, the skill was not loaded.

## If it doesn't load

- The folder must be named exactly `linkedin-outbound-sales`
- `SKILL.md` must sit at the top level of the folder, not in a subfolder
- In Claude, skills activate at session start; restart after copying
- Skills only trigger when the request is substantial - a short "write an
  intro message" may skip the skill. Give a real persona line and it fires