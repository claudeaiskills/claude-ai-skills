---
name: linkedin-outbound-sales
description: Turns a plain-text prospect description (job title, industry, 2-3 traits, what you sell) into a personalized LinkedIn connection request plus a 3-message follow-up sequence. Use this skill whenever the user wants to message strangers on LinkedIn, write a connection note or intro DM, run outbound sales outreach, craft follow-ups, respond to ignore, or build value-add comments for a prospect's posts - even if they never say "skill". Not for mass InMail template blasts; this is precision outreach for one person at a time.
---

# LinkedIn Outbound Sales

Turns one prospect description into outreach that gets replied to: a
connection request, two follow-up messages, and value-add comments for their
posts. The goal is a human reply, not a volume campaign. This skill exists
because "connect and pitch" does not work on LinkedIn - the opener must be
specific to the person, and the pitch must wait until after they reply.

## Quick start

Give the skill a prospect. One line is enough: job title, industry, what
they likely care about, and what you sell. Example:

"CTA for a US patient portal startup, sells to clinic owners - we build
local SEO for doctors."

You get back, in order:

1. Connection request (under 300 characters, no pitch)
2. Thank-you reply note for when they accept (under 120 words)
3. Day-2 follow-up (only if still silent)
4. Value-add comment ideas for 2 of their recent posts

## Workflow

Follow the steps in order. Supply the hook details yourself from the user's
description and from the prospect's profile if one is shared.

### Step 1 - Nail the persona

Before writing anything, state back in one line: who they sell to, and what
you sell. Then pick the strongest relevance hook for THIS prospect from what
you know:

- A shared specific (same niche, same city, same company size, a mutual contact)
- Something real on their profile you can reference (a post, a role, a result)
- Their obvious pain given the industry you sell into

If you have no hook at all, say so and ask for one detail before writing -
never invent a fake shared connection or cite a post you did not see.

### Step 2 - Write the connection request

Rules in priority order:

- Open with their name, then the specific hook in the first sentence
- Max 300 characters total. LinkedIn displays ~300 before "See more"
- Zero pitching. No "I help businesses...", no links, no "quick question"
- End with one soft ask: "Open to a short chat?" or "Would it help if I shared one idea?"
- Write like a colleague, not a salesperson. No "I hope this finds you well"

### Step 3 - Write the thanks-for-accepting note

After they accept, the first message must not pitch immediately. Content:

- 2-3 sentences: one line connecting back to the hook, then ask about their
  current priority in their own words
- Optional: one concrete free observation about their situation (only if
  you genuinely know something useful - never a generic compliment)
- No link yet. Links belong after they show interest

### Step 4 - Write the silent follow-up (Day 2-3)

One short message, different angle, still no pitch:

- Reference that you notice they're busy, offer one useful thing
- Or share a 1-sentence micro-result you saw somewhere relevant to them
- End with a low-effort question that only needs a yes/no

### Step 5 - Value-add comments

For the 2 most relevant posts you can find on their profile, write one
comment each:

- 10-20 words, adds a new angle on what THEY said (never "Great post!")
- Mentions a result or a counter-observation, asks nothing
- No links. No self-promotion

## Output format

Return exactly this structure, named blocks:

```
BRIEF
[one line: who they sell to / what you sell]

CONNECTION REQUEST
[full text, ready to copy]

THANKS NOTE
[copy when they accept]

FOLLOW-UP (DAY 2-3)
[send only if no reply]

COMMENTS
POST 1 | [topic]: [comment]
POST 2 | [topic]: [comment]
```

## Examples

**Example 1 - clean hook**

Brief: targets clinic owners in Morocco; sells medical SEO.

CONNECTION REQUEST
Salma, I noticed you grew your Marrakech clinic to 3 branches in 2 years.
I help clinics rank in AI search where new patients look first. Open to a
quick chat this week?

THANKS NOTE
Thanks for connecting. Curious what's driving most of your new patients
today - referral, ads, or search? Happy to share what I'm seeing for other
clinics in your region.

FOLLOW-UP (DAY 2-3)
Not going to chase you - just wanted to leave one idea: most clinics I see
lose leads to AI overviews because their pages aren't written for them.
If that rings true, tell me and I'll send a fix.

COMMENTS
POST 1 | patient retention: "The sticker on repeat bookings vs new ads - most clinics under-measure this one."
POST 2 | staff growth: "Hiring before demand is usually the safer bet in health."

**Example 2 - thin hook (what to do when you have little)**

Brief: SaaS founder selling to HR leads; prospect is an HR director with a
sparse profile.

CONNECTION REQUEST
Yasmine, I saw you lead HR for a 200-person logistics team. I help HR teams
cut recruitment time with AI - happy to share what that looks like in your
industry. Open to a chat?

Do the same for the rest. If the profile gave you nothing, keep the hook to
their company size and industry, and be honest that the idea is from you,
not them.

## When things go wrong

- No profile detail available: use company size + industry as the hook (see Example 2); never invent
- Prospect has a protected profile (no DMs): recommend a comment on their post instead, then connect later
- They reply but the call stalls: suggest one short check-in, then stop; do not nag
- You know nothing about their niche: ask the user one targeted question before writing rather than producing a generic note
- Connection cap or outreach limits: message politely with fewer connects per week; never encourage automation/spam tooling
- Requested "mass outreach": refuse politely and redirect to this one-at-a-time format (LinkedIn penalizes and bans spam volume)

## Reference file

For the message structure reasoning, tone rules, and the full working copy
patterns, read `references/message-structures.md`.