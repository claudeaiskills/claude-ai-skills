# Content Engine - Install Guide

Install time: under 2 minutes.

## What you get

- `SKILL.md` - the workflow that turns one topic into an outline, draft, and 5 titles
- `references/voice.md` - the writing rules every article follows
- `references/article-blueprint.md` - the article structure

## How to install

### If you use Claude (Desktop app / web with Projects, or Codex CLI)

1. Find your skills folder:
   - Claude Desktop: `~/.claude/skills/`
   - Codex CLI: `~/.codex/skills/`
2. Copy the whole `content-engine` folder into it.
3. Restart the app.
4. Clipping method: copy `SKILL.md` and `references/` into a project's
   `.claude/skills/content-engine/` folder instead, and it works per-project.

### If you use another AI tool

1. Keep this folder anywhere in the project.
2. In every session, paste a short pointer into the chat:

   "Read the file `skills/content-engine/SKILL.md` and `references/` inside
   that folder, then follow the workflow."

### Any tool with a custom-instructions slot

1. Open the tool's instructions or system-prompt setting.
2. Add one line:

   "A skill called Content Engine lives at [path]. When the user gives a
   topic, load it and run its workflow."

## First run check

After installing, type one topic such as:

"One article about scheduling content for a small business."

You should get: OUTLINE, DRAFT, TITLES, HANDOFF - in that order. If the
order is wrong, the skill was not loaded.

## If it doesn't load

- The folder must be named exactly `content-engine`.
- `SKILL.md` must be at the top level of the folder, not inside a subfolder.
- In Claude, skills only activate when the tool looks for them at session
  start; restart after copying.