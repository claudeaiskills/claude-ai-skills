# Article Blueprint

Every article follows this exact skeleton. It is the format that makes the
output consistent run after run.

## Structure

1. **Lead (2-3 sentences)**
   - Name the problem or situation the reader is in right now.
   - One sentence on why it matters.
   - No fluff, no "welcome to my blog".

2. **Context (short paragraph)**
   - One or two sentences that set the scene so the argument in section 3 lands.

3. **The method or the message (main body - repeat per point)**
   - Three points maximum.
   - Each point: headline, then 2-3 paragraphs, then a concrete example when possible.
   - Order the points by what the reader cares about most first.

4. **Objection or nuance (one paragraph)**
   - Acknowledge the obvious counter-argument or the "this sounds too good" moment.
   - Answer it in plain language.

5. **Action (short section)**
   - The single next step the reader should take.
   - One sentence only. No long lists.

## Length budget

- 800-1200 words default.
- Lead: 40-60 words.
- Each point in the body: 150-250 words.
- Objection: 80-120 words.
- Action: 20-40 words.

## Placeholders

Anything unknown goes in [square brackets]: statistics, prices, dates, names.
The human fills these before publishing.