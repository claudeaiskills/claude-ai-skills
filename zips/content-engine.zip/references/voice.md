# Voice Rules

The tone is the same for every article produced by this skill.

## Read out loud test

If the sentence feels robotic read out loud, rewrite it.

## Rules

- Write for a busy business owner, not for a journalist.
- Short sentences. One idea per sentence where possible.
- Short paragraphs. Three to five lines maximum.
- Plain words over fancy words. "Use" not "utilize". "Help" not "facilitate".
- No intro throat-clearing. Start on the topic in the first sentence.
- No corporate filler: "In today's fast-paced world", "unlock", "leverage", "elevate", "seamless".
- No en dashes or em dashes. Use a normal hyphen.
- No emoji characters.
- Contractions are welcome: "it's", "you'll", "that's".
- Second person, direct address: "you" and "your" throughout.
- Concrete over abstract. Show the example, then the rule.
- No numbers invented. If a stat is unknown, put [source] as a placeholder.
- The call to action, if present, is one line and modest. No hard selling.