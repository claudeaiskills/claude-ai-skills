# Installing Karpathy Guidelines

## 1. Create the folder

    mkdir -p ~/.claude/skills/karpathy-guidelines

On Windows use %USERPROFILE%\.claude\skills\karpathy-guidelines instead.

## 2. Drop the files in

Copy everything from this zip into that folder, so you end up with:

    karpathy-guidelines/SKILL.md

## 3. Restart Claude

Skills are discovered at session start. Restart your session and ask for
Karpathy Guidelines by name.

---

## Where this came from

- Skill: Karpathy Guidelines
- Author / repository: forrestchang/andrej-karpathy-skills
- Licence: NONE DECLARED
- Upstream: https://github.com/forrestchang/andrej-karpathy-skills
- Recorded: 215,157 stars

We did not write Karpathy Guidelines. We packaged it so you could install it in one step.
The original work belongs to the author above. Licence and source details are
in SOURCE.txt inside this zip.
